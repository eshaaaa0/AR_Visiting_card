import * as THREE from '../libs/three.module.js';
import *SOME_AR_ENGINE from '';

console.log("THREE" , THREE);

document.addEventListener("DOMContentLoaded", () => {
	const scene = new THREE.Scene();
	const geometry = new THREE.BoxGeometry(1, 1, 1);
	const material = new THREE.MeshBasicMaterial({color: "#0000ff"});
	const cube = new THREE.Mesh(geometry, material);

	scene.add(cube);
	cube.position.set(0, 0, -2);
	cube.rotation.set(0, Math.PI/4, 0, );

	const camera = new THREE.PerspectiveCamera();
	camera.position.set(1, 1, 5);

	const renderer = new THREE.WebGLRenderer({alpha: true});
	renderer.setSize(500, 500);
	renderer.render(scene, camera);

	const video = document.createElement("video");
	navigator.mediaDevices.getUserMedia({video: true}). then((stream) => {
		video.srcObject = stream;
		video.play();


	});

video.style.position = "absolute";
renderer.domElement.style.position = "absolute";
video.style.width = renderer.domElement.width;
video.style.height = renderer.domElement.height;

document.body.appendChild(video);

document.body.appendChild(renderer.domElement);

while ({video : true}) {
awwait nextVideoFrameReady();
const ar = new SOME_AR_ENGINE;
const {postion,rotation} = ar.computeCameraPose(video);
camera.postion = postion;
camera.rotation = rotation;
}

})